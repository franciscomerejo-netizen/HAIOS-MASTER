
export class AuthService {
  async login(email: string, password: string) {
    return { access_token: 'jwt-token-placeholder' };
  }
}
