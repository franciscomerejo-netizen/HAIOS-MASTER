
export class User {
  id: string;
  email: string;
  passwordHash: string;
  fullName: string;
}
