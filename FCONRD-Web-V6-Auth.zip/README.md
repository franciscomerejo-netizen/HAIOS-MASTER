# FCO.NRD V6 - Authentication Foundation

Incluye:
- JWT Strategy (base)
- Login DTO
- Register DTO
- User Entity
- PostgreSQL connection template
- Variables de entorno ejemplo
