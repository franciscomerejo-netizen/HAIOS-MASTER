# FCO.NRD V8 - Leads + Pipeline Real

Incluye:
- Lead Entity
- Lead Score Entity
- Lead Activity Entity
- Leads Controller
- Leads Service
- Pipeline Stages
- Conversión Lead -> Opportunity
- Preparación para Sofía IA
