
export class LeadScore {
  id: string;
  leadId: string;
  score: number;
  reason?: string;
}
