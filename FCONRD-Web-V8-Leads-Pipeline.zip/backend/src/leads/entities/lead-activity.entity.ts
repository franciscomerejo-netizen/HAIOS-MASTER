
export class LeadActivity {
  id: string;
  leadId: string;
  activity: string;
  createdAt: Date;
}
