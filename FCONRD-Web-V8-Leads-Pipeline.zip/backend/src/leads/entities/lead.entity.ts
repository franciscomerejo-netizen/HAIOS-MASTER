
export class Lead {
  id: string;
  name: string;
  email: string;
  phone?: string;
  country?: string;
  source?: string;
  status: string;
  score: number;
}
