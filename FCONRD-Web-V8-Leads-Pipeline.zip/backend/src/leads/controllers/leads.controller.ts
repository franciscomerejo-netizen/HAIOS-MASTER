
export class LeadsController {
  create() {}
  findAll() {}
  findOne() {}
  update() {}
  convert() {}
}
