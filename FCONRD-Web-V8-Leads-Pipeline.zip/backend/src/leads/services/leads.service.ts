
export class LeadsService {
  createLead(){}
  scoreLead(){}
  movePipeline(){}
  convertToOpportunity(){}
}
