
export default function Dashboard() {
 return <h1>Dashboard Ejecutivo</h1>
}
