
export default function Home() {
 return <h1>FCO.NRD V4 Plataforma SaaS</h1>
}
