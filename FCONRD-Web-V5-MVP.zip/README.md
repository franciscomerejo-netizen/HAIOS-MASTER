# FCO.NRD MVP V5
Objetivo:
- Login JWT
- Leads CRM
- Dashboard
- Base PostgreSQL
- IA Sofia (stub)
- IA Daniela (stub)
