
export class CrmController {
  pipeline(){ return [] }
}
