
export class LeadsController {
  findAll(){ return [] }
}
