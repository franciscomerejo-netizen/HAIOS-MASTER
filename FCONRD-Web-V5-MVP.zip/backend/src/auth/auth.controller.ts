
export class AuthController {
  login(){ return {message:'login endpoint'} }
}
