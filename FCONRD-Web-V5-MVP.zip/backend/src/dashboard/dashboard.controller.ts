
export class DashboardController {
  executive(){ return { leads:0, conversions:0 } }
}
