# FCO.NRD V9 - Sofia IA

Funciones:
- Lead Scoring Inteligente
- Clasificación HOT/WARM/COLD
- Seguimiento Automático
- Historial de Conversaciones
- Recomendaciones de Conversión
- Integración CRM
