
USA = +20
Capital > 10000 = +40
Interés Alto = +30
Email válido = +10
