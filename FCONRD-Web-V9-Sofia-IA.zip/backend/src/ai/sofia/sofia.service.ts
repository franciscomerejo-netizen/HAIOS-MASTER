
export class SofiaService {
  calculateLeadScore() {}
  classifyLead() {}
  generateFollowUp() {}
  recommendNextAction() {}
}
