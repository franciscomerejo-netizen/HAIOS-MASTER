
export class AIConversation {
  id: string;
  leadId: string;
  message: string;
  role: string;
  createdAt: Date;
}
