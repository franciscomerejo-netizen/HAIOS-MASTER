# FCO.NRD Web V3
Stack objetivo:
- Next.js
- TailwindCSS
- CRM
- Dashboard CEO
- IA Sofía
- IA Daniela
