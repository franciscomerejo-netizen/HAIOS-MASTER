
export default function CRM(){
 return <h1>CRM Leads & Opportunities</h1>
}
