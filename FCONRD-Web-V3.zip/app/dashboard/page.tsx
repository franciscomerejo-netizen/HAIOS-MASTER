
export default function Dashboard(){
 return <h1>Dashboard Ejecutivo CEO</h1>
}
