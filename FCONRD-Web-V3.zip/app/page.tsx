
export default function Home(){
 return (
  <main>
   <h1>FCO.NRD Inversiones</h1>
   <p>Inversiones inteligentes impulsadas por IA</p>
  </main>
 )
}
