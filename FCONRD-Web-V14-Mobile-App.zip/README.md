# FCO.NRD V14 - Aplicación Móvil

Stack:
- React Native
- Expo
- TypeScript

Módulos:
- CEO Dashboard
- CRM Mobile
- Leads
- Oportunidades
- Sofía IA
- Daniela IA
- Notificaciones Push
