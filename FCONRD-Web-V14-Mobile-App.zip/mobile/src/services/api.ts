
export const API_BASE_URL = 'https://api.fconrd.com';
