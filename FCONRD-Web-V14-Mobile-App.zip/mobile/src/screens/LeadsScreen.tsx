
export default function LeadsScreen() {
  return null;
}
