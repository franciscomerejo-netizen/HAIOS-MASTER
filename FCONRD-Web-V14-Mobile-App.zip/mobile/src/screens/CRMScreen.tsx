
export default function CRMScreen() {
  return null;
}
