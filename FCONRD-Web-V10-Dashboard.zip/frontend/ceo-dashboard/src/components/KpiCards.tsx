
export default function KpiCards() {
  return <div>KPIs: Leads, Conversiones, ROI, MRR</div>;
}
