
export default function PipelineBoard() {
  return <div>Pipeline Comercial</div>;
}
