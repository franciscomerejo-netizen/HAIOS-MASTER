
export default function AIMetrics() {
  return <div>Métricas Sofía IA</div>;
}
