
CEO Dashboard
- Leads Totales
- Leads HOT/WARM/COLD
- Oportunidades
- Ventas
- ROI
- Coste IA por Lead
- Conversion Rate
