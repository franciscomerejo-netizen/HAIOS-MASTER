@echo off
title HORIZONS - Mercado de Empleados IA
echo ============================================
echo   HORIZONS - Iniciando tu servidor local...
echo ============================================
echo.
cd /d "%~dp0pocketbase"
start "" "http://127.0.0.1:8090"
pocketbase.exe serve
pause
