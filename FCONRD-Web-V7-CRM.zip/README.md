# FCO.NRD V7 CRM Funcional

Incluye:
- Customers
- Opportunities
- Pipeline
- Tasks
- Activities
- Calendar Events
- Conversión Lead -> Customer
