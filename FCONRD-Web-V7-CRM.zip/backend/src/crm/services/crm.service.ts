
export class CrmService {
  createCustomer(){}
  createOpportunity(){}
  movePipelineStage(){}
  convertLeadToCustomer(){}
}
