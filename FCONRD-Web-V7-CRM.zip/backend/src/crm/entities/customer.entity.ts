
export class Customer {
  id: string;
  fullName: string;
  email: string;
  phone?: string;
  country?: string;
}
