
export class Opportunity {
  id: string;
  customerId: string;
  title: string;
  value: number;
  stage: string;
}
