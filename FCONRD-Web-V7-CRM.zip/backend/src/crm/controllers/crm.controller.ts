
export class CrmController {
  customers() {}
  opportunities() {}
  pipeline() {}
  convertLead() {}
}
