# FCO.NRD V11 - Daniela IA

Funciones:
- Generación de propuestas
- Análisis de objeciones
- Predicción de cierre
- Riesgo de oportunidad
- Recomendación comercial
- Integración CRM + Dashboard
