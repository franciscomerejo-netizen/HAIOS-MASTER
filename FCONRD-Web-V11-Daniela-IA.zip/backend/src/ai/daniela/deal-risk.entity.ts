
export class DealRisk {
  opportunityId: string;
  riskLevel: string;
  probability: number;
}
