
Probability Score
90-100 = Very High
70-89  = High
50-69  = Medium
0-49   = Low
