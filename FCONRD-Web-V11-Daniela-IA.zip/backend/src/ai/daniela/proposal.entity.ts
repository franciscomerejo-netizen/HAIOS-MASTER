
export class Proposal {
  id: string;
  opportunityId: string;
  title: string;
  value: number;
  status: string;
}
