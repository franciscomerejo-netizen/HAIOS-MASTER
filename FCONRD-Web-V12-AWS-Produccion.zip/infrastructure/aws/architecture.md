
Internet
  |
CloudFront
  |
WAF
  |
Load Balancer
  |
ECS/EKS
  |------ API
  |------ CRM
  |------ IA
  |
RDS PostgreSQL
ElastiCache Redis
S3 Documents
Secrets Manager
CloudWatch
