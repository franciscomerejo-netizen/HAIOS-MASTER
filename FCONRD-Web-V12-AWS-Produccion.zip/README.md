# FCO.NRD V12 - AWS Producción

Infraestructura objetivo:
- AWS RDS PostgreSQL
- ElastiCache Redis
- ECS/EKS
- S3
- CloudFront
- WAF
- Secrets Manager
- CloudWatch
- GitHub Actions CI/CD
